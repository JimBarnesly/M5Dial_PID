#include "StorageManager.h"
#include <ArduinoJson.h>
#include <cstring>
#include <esp_system.h>
#include <esp_flash_encrypt.h>

bool StorageManager::encryptedStorageAvailable() const {
  return esp_flash_encryption_enabled();
}

void StorageManager::begin() {
  _prefs.begin("env-ctrl", false);
  _lastSavedJson = _prefs.getString("cfg", "");
}

void StorageManager::loadDefaults(PersistentConfig& cfg) {
  memset(&cfg, 0, sizeof(cfg));
  cfg.controlLock = ControlLock::LocalOrRemote;
  cfg.localSetpointC = 65.0f;
  cfg.stageStartBandC = 2.0f;
  cfg.manualStageMinutes = 60;
  cfg.overTempC = 99.0f;
  cfg.tempOffsetC = 0.0f;
  cfg.tempSmoothingAlpha = CoreConfig::DEFAULT_TEMP_SMOOTHING_ALPHA;
  strncpy(cfg.mqttHost, "10.42.0.1", sizeof(cfg.mqttHost)-1);
  cfg.mqttPort = CoreConfig::MQTT_PORT_PLAIN;
  cfg.mqttUseTls = false;
  cfg.mqttTlsAuthMode = 0;
  cfg.mqttTlsFingerprint[0] = '\0';
  cfg.mqttTlsCaCert[0] = '\0';
  cfg.mqttCommsTimeoutSec = 0;
  cfg.mqttFallbackMode = MqttFallbackMode::HoldSetpoint;
  cfg.wifiPortalTimeoutSec = CoreConfig::DEFAULT_WIFI_PORTAL_TIMEOUT_SEC;
  cfg.pidKp = CoreConfig::PID_KP;
  cfg.pidKi = CoreConfig::PID_KI;
  cfg.pidKd = CoreConfig::PID_KD;
  cfg.prevPidKp = cfg.pidKp;
  cfg.prevPidKi = cfg.pidKi;
  cfg.prevPidKd = cfg.pidKd;
  cfg.tuneQualityScore = 0.0f;
  cfg.profileCount = 0;
  cfg.activeProfileIndex = 0;
}

bool StorageManager::load(PersistentConfig& cfg) {
  String json = _prefs.getString("cfg", "");
  _lastSavedJson = json;
  if (json.isEmpty()) {
    loadDefaults(cfg);
    save(cfg);
    return true;
  }

  JsonDocument doc;
  DeserializationError err = deserializeJson(doc, json);
  if (err) {
    loadDefaults(cfg);
    save(cfg);
    return false;
  }

  loadDefaults(cfg);
  cfg.localSetpointC = doc["localSetpointC"] | cfg.localSetpointC;
  cfg.stageStartBandC = doc["stageStartBandC"] | cfg.stageStartBandC;
  cfg.manualStageMinutes = doc["manualStageMinutes"] | cfg.manualStageMinutes;
  cfg.overTempC = doc["overTempC"] | cfg.overTempC;
  cfg.tempOffsetC = doc["tempOffsetC"] | cfg.tempOffsetC;
  cfg.tempSmoothingAlpha = doc["tempSmoothingAlpha"] | cfg.tempSmoothingAlpha;
  cfg.controlLock = static_cast<ControlLock>((uint8_t)(doc["controlLock"] | (uint8_t)cfg.controlLock));
  const char* mqttHostDefault = "10.42.0.1";
  const bool migrated = strcmp(doc["mqttHost"] | mqttHostDefault, mqttHostDefault) != 0;
  strlcpy(cfg.mqttHost, mqttHostDefault, sizeof(cfg.mqttHost));
  cfg.mqttPort = doc["mqttPort"] | cfg.mqttPort;
  cfg.mqttUseTls = doc["mqttUseTls"] | cfg.mqttUseTls;
  cfg.mqttTlsAuthMode = doc["mqttTlsAuthMode"] | cfg.mqttTlsAuthMode;
  cfg.mqttCommsTimeoutSec = doc["mqttCommsTimeoutSec"] | cfg.mqttCommsTimeoutSec;
  cfg.mqttFallbackMode = static_cast<MqttFallbackMode>((uint8_t)(doc["mqttFallbackMode"] | (uint8_t)cfg.mqttFallbackMode));
  cfg.wifiPortalTimeoutSec = doc["wifiPortalTimeoutSec"] | cfg.wifiPortalTimeoutSec;
  const bool canLoadSecrets = encryptedStorageAvailable();
  if (canLoadSecrets) {
    strlcpy(cfg.mqttUser, doc["mqttUser"] | cfg.mqttUser, sizeof(cfg.mqttUser));
    strlcpy(cfg.mqttPass, doc["mqttPass"] | cfg.mqttPass, sizeof(cfg.mqttPass));
    strlcpy(cfg.mqttTlsFingerprint, doc["mqttTlsFingerprint"] | cfg.mqttTlsFingerprint, sizeof(cfg.mqttTlsFingerprint));
    strlcpy(cfg.mqttTlsCaCert, doc["mqttTlsCaCert"] | cfg.mqttTlsCaCert, sizeof(cfg.mqttTlsCaCert));
  } else {
    cfg.mqttUser[0] = '\0';
    cfg.mqttPass[0] = '\0';
    cfg.mqttTlsFingerprint[0] = '\0';
    cfg.mqttTlsCaCert[0] = '\0';
  }
  cfg.pidKp = doc["pidKp"] | cfg.pidKp;
  cfg.pidKi = doc["pidKi"] | cfg.pidKi;
  cfg.pidKd = doc["pidKd"] | cfg.pidKd;
  cfg.prevPidKp = doc["prevPidKp"] | cfg.prevPidKp;
  cfg.prevPidKi = doc["prevPidKi"] | cfg.prevPidKi;
  cfg.prevPidKd = doc["prevPidKd"] | cfg.prevPidKd;
  cfg.tuneQualityScore = doc["tuneQualityScore"] | cfg.tuneQualityScore;
  cfg.profileCount = static_cast<uint8_t>(doc["profileCount"] | cfg.profileCount);
  cfg.activeProfileIndex = static_cast<uint8_t>(doc["activeProfileIndex"] | cfg.activeProfileIndex);

  JsonArray profiles = doc["profiles"].as<JsonArray>();
  if (!profiles.isNull()) {
    cfg.profileCount = 0;
    for (JsonObject p : profiles) {
      if (cfg.profileCount >= CoreConfig::MAX_PROFILES) break;
      ProcessProfile& profile = cfg.profiles[cfg.profileCount];
      strlcpy(profile.name, p["name"] | "PROFILE", sizeof(profile.name));
      profile.stageCount = static_cast<uint8_t>(p["stageCount"] | 0);
      if (profile.stageCount > CoreConfig::MAX_STAGES) profile.stageCount = CoreConfig::MAX_STAGES;

      JsonArray stages = p["stages"].as<JsonArray>();
      uint8_t loadedStages = 0;
      if (!stages.isNull()) {
        for (JsonObject s : stages) {
          if (loadedStages >= profile.stageCount || loadedStages >= CoreConfig::MAX_STAGES) break;
          ProcessStage& stage = profile.stages[loadedStages];
          strlcpy(stage.name, s["name"] | "STAGE", sizeof(stage.name));
          stage.targetC = s["targetC"] | 0.0f;
          stage.holdSeconds = s["holdSeconds"] | 0UL;
          ++loadedStages;
        }
      }
      profile.stageCount = loadedStages;
      ++cfg.profileCount;
    }
  }

  if (cfg.profileCount == 0) {
    cfg.activeProfileIndex = 0;
  } else if (cfg.activeProfileIndex >= cfg.profileCount) {
    cfg.activeProfileIndex = static_cast<uint8_t>(cfg.profileCount - 1);
  }
  if (migrated) save(cfg);
  return true;
}

void StorageManager::save(const PersistentConfig& cfg) {
  JsonDocument doc;
  doc["localSetpointC"] = cfg.localSetpointC;
  doc["stageStartBandC"] = cfg.stageStartBandC;
  doc["manualStageMinutes"] = cfg.manualStageMinutes;
  doc["overTempC"] = cfg.overTempC;
  doc["tempOffsetC"] = cfg.tempOffsetC;
  doc["tempSmoothingAlpha"] = cfg.tempSmoothingAlpha;
  doc["controlLock"] = (uint8_t)cfg.controlLock;
  doc["mqttHost"] = cfg.mqttHost;
  doc["mqttPort"] = cfg.mqttPort;
  doc["mqttUseTls"] = cfg.mqttUseTls;
  doc["mqttTlsAuthMode"] = cfg.mqttTlsAuthMode;
  doc["mqttCommsTimeoutSec"] = cfg.mqttCommsTimeoutSec;
  doc["mqttFallbackMode"] = static_cast<uint8_t>(cfg.mqttFallbackMode);
  doc["wifiPortalTimeoutSec"] = cfg.wifiPortalTimeoutSec;
  if (encryptedStorageAvailable()) {
    doc["mqttUser"] = cfg.mqttUser;
    doc["mqttPass"] = cfg.mqttPass;
    doc["mqttTlsFingerprint"] = cfg.mqttTlsFingerprint;
    doc["mqttTlsCaCert"] = cfg.mqttTlsCaCert;
  }
  doc["pidKp"] = cfg.pidKp;
  doc["pidKi"] = cfg.pidKi;
  doc["pidKd"] = cfg.pidKd;
  doc["prevPidKp"] = cfg.prevPidKp;
  doc["prevPidKi"] = cfg.prevPidKi;
  doc["prevPidKd"] = cfg.prevPidKd;
  doc["tuneQualityScore"] = cfg.tuneQualityScore;
  doc["profileCount"] = cfg.profileCount;
  doc["activeProfileIndex"] = cfg.activeProfileIndex;

  JsonArray profiles = doc["profiles"].to<JsonArray>();
  const uint8_t profileCount = (cfg.profileCount > CoreConfig::MAX_PROFILES) ? CoreConfig::MAX_PROFILES : cfg.profileCount;
  for (uint8_t i = 0; i < profileCount; ++i) {
    const ProcessProfile& profile = cfg.profiles[i];
    JsonObject p = profiles.add<JsonObject>();
    p["name"] = profile.name;
    const uint8_t stageCount = (profile.stageCount > CoreConfig::MAX_STAGES) ? CoreConfig::MAX_STAGES : profile.stageCount;
    p["stageCount"] = stageCount;
    JsonArray stages = p["stages"].to<JsonArray>();
    for (uint8_t j = 0; j < stageCount; ++j) {
      const ProcessStage& stage = profile.stages[j];
      JsonObject s = stages.add<JsonObject>();
      s["name"] = stage.name;
      s["targetC"] = stage.targetC;
      s["holdSeconds"] = stage.holdSeconds;
    }
  }


  String out;
  serializeJson(doc, out);
  if (out == _lastSavedJson) return;
  _prefs.putString("cfg", out);
  _lastSavedJson = out;
}
