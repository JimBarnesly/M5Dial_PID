#include "WifiManagerWrapper.h"
#include "core/CoreConfig.h"
#include <WiFi.h>
#include <esp_wifi_types.h>

void WifiManagerWrapper::transitionTo(State next) {
  if (_state == next) return;
  _state = next;

  const char* label = "idle";
  switch (_state) {
    case State::Idle: label = "idle"; break;
    case State::Connecting: label = "connecting"; break;
    case State::PortalActive: label = "portal_active"; break;
    case State::Connected: label = "connected"; break;
  }
  Serial.printf("[WiFi] state=%s integrated=%d\n", label, _integratedMode);
}

bool WifiManagerWrapper::hasSavedCredentials() const {
  return WiFi.SSID().length() > 0;
}

void WifiManagerWrapper::startBackgroundPortal() {
  if (_portalForced) return;

  Serial.printf("[WiFi] starting background portal ap=%s timeout=%u\n", _apName, _portalTimeoutSec);
  _wm.startConfigPortal(_apName, _apPass);
  _portalForced = true;
  transitionTo(State::PortalActive);
}

void WifiManagerWrapper::buildPortalCredentials() {
  uint64_t efuseMac = ESP.getEfuseMac();
  uint32_t suffix = static_cast<uint32_t>(efuseMac & 0xFFFFFFULL);
  snprintf(_apName, sizeof(_apName), "%s%06lX", CoreConfig::WIFI_AP_NAME_PREFIX, static_cast<unsigned long>(suffix));
  snprintf(_apPass,
           sizeof(_apPass),
           "%s%06lX!",
           CoreConfig::WIFI_AP_PASS_PREFIX,
           static_cast<unsigned long>(suffix));
}

void WifiManagerWrapper::beginStandalone(uint16_t portalTimeoutSec) {
  buildPortalCredentials();
  _integratedMode = false;
  _managedSsid[0] = '\0';
  _managedPass[0] = '\0';
  _portalTimeoutSec = portalTimeoutSec;

  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.setSleep(false);
  WiFi.persistent(true);

  _wm.setDebugOutput(true);
  _wm.setConnectRetries(8);
  _wm.setConfigPortalBlocking(false);
  _wm.setConfigPortalTimeout(portalTimeoutSec);

  _portalForced = false;
  _authExpireCount = 0;
  _lastAuthExpireMs = 0;
  _lastReconnectAttemptMs = millis();
  transitionTo(State::Idle);

  WiFi.onEvent([this](WiFiEvent_t event, WiFiEventInfo_t info) {
    if (event != ARDUINO_EVENT_WIFI_STA_DISCONNECTED) return;
    const uint8_t reason = info.wifi_sta_disconnected.reason;
    if (reason != WIFI_REASON_AUTH_EXPIRE) return;

    const uint32_t now = millis();
    if (_lastAuthExpireMs == 0 || now - _lastAuthExpireMs > 15000) _authExpireCount = 1;
    else if (_authExpireCount < 255) ++_authExpireCount;
    _lastAuthExpireMs = now;

    if (_authExpireCount >= 3) _portalForced = false;
  });

  if (hasSavedCredentials()) {
    Serial.printf("[WiFi] attempting saved credentials SSID=%s\n", WiFi.SSID().c_str());
    WiFi.begin();
    transitionTo(State::Connecting);
  } else {
    Serial.println("[WiFi] no saved credentials; portal deferred to background update");
  }

  _started = true;
}

void WifiManagerWrapper::beginIntegrated(const char* ssid, const char* password) {
  buildPortalCredentials();
  _integratedMode = true;
  strlcpy(_managedSsid, ssid ? ssid : "", sizeof(_managedSsid));
  strlcpy(_managedPass, password ? password : "", sizeof(_managedPass));

  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  WiFi.setSleep(false);
  WiFi.persistent(false);

  _portalForced = false;
  _authExpireCount = 0;
  _lastAuthExpireMs = 0;
  _lastReconnectAttemptMs = millis();
  transitionTo(State::Connecting);

  Serial.printf("[WiFi] integrated connect SSID=%s\n", _managedSsid);
  WiFi.disconnect(false, false);
  delay(100);
  WiFi.begin(_managedSsid, _managedPass);
  _started = true;
}

void WifiManagerWrapper::update() {
  if (!_started) return;

  if (WiFi.status() == WL_CONNECTED) {
    transitionTo(State::Connected);
  } else if (_state == State::Connected) {
    transitionTo(State::Connecting);
  }

  if (_integratedMode) {
    if (WiFi.status() != WL_CONNECTED && millis() - _lastReconnectAttemptMs > 10000) {
      _lastReconnectAttemptMs = millis();
      Serial.printf("[WiFi] reconnect attempt integrated SSID=%s\n", _managedSsid);
      WiFi.disconnect(false, false);
      delay(50);
      WiFi.begin(_managedSsid, _managedPass);
      transitionTo(State::Connecting);
    }
    return;
  }

  _wm.process();
  if (WiFi.status() == WL_CONNECTED) return;

  if (_authExpireCount >= 6 && !_portalForced) {
    Serial.println("[WiFi] repeated AUTH_EXPIRE; clearing settings and starting portal");
    resetSettings();
    _authExpireCount = 0;
    startBackgroundPortal();
    return;
  }

  if (!_portalForced) {
    if (hasSavedCredentials()) {
      if (millis() - _lastReconnectAttemptMs > 10000) {
        _lastReconnectAttemptMs = millis();
        Serial.println("[WiFi] reconnect attempt using saved credentials");
        WiFi.disconnect(false, false);
        delay(50);
        WiFi.begin();
        transitionTo(State::Connecting);
      }
    } else {
      startBackgroundPortal();
    }
  }
}

bool WifiManagerWrapper::isConnected() const {
  return WiFi.status() == WL_CONNECTED;
}

const char* WifiManagerWrapper::getPortalApName() const {
  return _apName;
}

const char* WifiManagerWrapper::getPortalApPassword() const {
  return _apPass;
}

void WifiManagerWrapper::resetSettings() {
  _wm.resetSettings();
  _managedSsid[0] = '\0';
  _managedPass[0] = '\0';
  _integratedMode = false;
  _portalForced = false;
  WiFi.disconnect(true, true);
  delay(120);
  WiFi.mode(WIFI_OFF);
  delay(120);
  WiFi.mode(WIFI_STA);
  transitionTo(State::Idle);
}
